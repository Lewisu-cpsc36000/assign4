#pragma once
// Standard Sketcher element type identifiers
enum class ElementType { LINE, RECTANGLE, CIRCLE, CURVE, ELLIPSE };