
// Adrian Siwy, Leonard Flores, David Gagnon
// Assignment 4 Problem 3 -> UI for Assignment 2 problem 4
// Created dialogue boxes that appear when the user clicks on Account -> Add and Account -> Find
// The user would enter the new entry and use the find tool to retrieve information
// Attempted to make the Account code work with the user interface

#include "stdafx.h"
#include "Account.h"
#include <vector>
#include <iostream>
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "Assign4Prob3.h"
#endif

#include "Assign4Prob3Doc.h"
#include "AddAddressDlg.h"
#include "FindDlg.h"

#include <propkey.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CAssign4Prob3Doc

IMPLEMENT_DYNCREATE(CAssign4Prob3Doc, CDocument)

BEGIN_MESSAGE_MAP(CAssign4Prob3Doc, CDocument)
	ON_COMMAND(ID_ADDRESS_ADD, &CAssign4Prob3Doc::OnAddressAdd)
	ON_UPDATE_COMMAND_UI(ID_ADDRESS_ADD, &CAssign4Prob3Doc::OnUpdateAddressAdd)
	ON_COMMAND(ID_ADDRESS_FIND, &CAssign4Prob3Doc::OnAddressFind)
	ON_UPDATE_COMMAND_UI(ID_ADDRESS_FIND, &CAssign4Prob3Doc::OnUpdateAddressFind)
END_MESSAGE_MAP()


// CAssign4Prob3Doc construction/destruction

CAssign4Prob3Doc::CAssign4Prob3Doc()
{
	// TODO: add one-time construction code here
}

CAssign4Prob3Doc::~CAssign4Prob3Doc()
{
}

BOOL CAssign4Prob3Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	if (!m_viewList.IsEmpty())
	{
		reinterpret_cast<CEditView*>(m_viewList.GetHead())->SetWindowText(NULL);
	}

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// CAssign4Prob3Doc serialization

void CAssign4Prob3Doc::Serialize(CArchive& ar)
{
	// CEditView contains an edit control which handles all serialization
	if (!m_viewList.IsEmpty())
	{
		reinterpret_cast<CEditView*>(m_viewList.GetHead())->SerializeRaw(ar);
	}
#ifdef SHARED_HANDLERS

	if (m_viewList.IsEmpty() && ar.IsLoading())
	{
		CFile* pFile = ar.GetFile();
		pFile->Seek(0, FILE_BEGIN);
		ULONGLONG nFileSizeBytes = pFile->GetLength();
		ULONGLONG nFileSizeChars = nFileSizeBytes/sizeof(TCHAR);
		LPTSTR lpszText = (LPTSTR)malloc(((size_t)nFileSizeChars + 1) * sizeof(TCHAR));
		if (lpszText != NULL)
		{
			ar.Read(lpszText, (UINT)nFileSizeBytes);
			lpszText[nFileSizeChars] = '\0';
			m_strThumbnailContent = lpszText;
			m_strSearchContent = lpszText;
		}
	}
#endif
}

#ifdef SHARED_HANDLERS

// Support for thumbnails
void CAssign4Prob3Doc::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// Modify this code to draw the document's data
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(m_strThumbnailContent, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// Support for Search Handlers
void CAssign4Prob3Doc::InitializeSearchContent()
{
	// Set search contents from document's data. 
	// The content parts should be separated by ";"

	// Use the entire text file content as the search content.
	SetSearchContent(m_strSearchContent);
}

void CAssign4Prob3Doc::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = NULL;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != NULL)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CAssign4Prob3Doc diagnostics

#ifdef _DEBUG
void CAssign4Prob3Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CAssign4Prob3Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CAssign4Prob3Doc commands


void CAssign4Prob3Doc::OnAddressAdd()
{
	CAddAddressDlg dlgBox;
	dlgBox.DoModal();

	vector<Account> data;

	// TODO: Add your command handler code here
	//create the vector of people

	//data to be entered
}


void CAssign4Prob3Doc::OnUpdateAddressAdd(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	
}


void CAssign4Prob3Doc::OnAddressFind()
{
	// TODO: Add your command handler code here
	CFindDlg dlgBox;
	dlgBox.DoModal();
}


void CAssign4Prob3Doc::OnUpdateAddressFind(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
}
