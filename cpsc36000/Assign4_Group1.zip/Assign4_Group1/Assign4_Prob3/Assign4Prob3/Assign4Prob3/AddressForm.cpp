// AddressForm.cpp : implementation file
//

#include "stdafx.h"
#include "Assign4Prob3.h"
#include "AddressForm.h"


// AddressForm

IMPLEMENT_DYNCREATE(AddressForm, CFormView)

AddressForm::AddressForm()
	: CFormView(IDD_DIALOG1)
{

}

AddressForm::~AddressForm()
{
}

void AddressForm::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(AddressForm, CFormView)
END_MESSAGE_MAP()


// AddressForm diagnostics

#ifdef _DEBUG
void AddressForm::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void AddressForm::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// AddressForm message handlers
