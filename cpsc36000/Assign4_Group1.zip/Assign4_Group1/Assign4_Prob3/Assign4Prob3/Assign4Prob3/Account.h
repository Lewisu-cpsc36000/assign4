#pragma once

#include <string>
using namespace std;

class Account
{
public:
	Account();
	~Account();

	Account(string firstName, string lastName, string street, string city, string state, string zipCode);
	string getFirstName();
	void displayData();

private:
	string firstName;
	string lastName;
	//These were in the Address object before but for some reason the compiler was freaking out
	string street;
	string city;
	string state;
	string zipCode;
};

