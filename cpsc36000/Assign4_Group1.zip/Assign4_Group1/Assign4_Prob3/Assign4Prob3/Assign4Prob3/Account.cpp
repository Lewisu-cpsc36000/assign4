#include "stdafx.h"
#include "Account.h"
#include "stdafx.h"
#include "iostream"

Account::Account()
{
}

Account::~Account()
{
}

Account::Account(string firstName, string lastName, string street, string city, string state, string zipCode)
{
	this->firstName = firstName;
	this->lastName = lastName;
	this->street = street;
	this->city = city;
	this->state = state;
	this->zipCode = zipCode;
}

string Account::getFirstName()
{
	return firstName;
}

//display the person's data
void Account::displayData() {
	cout << "Name:" << endl
		<< firstName << " "
		<< lastName << endl
		<< "Address:" << endl
		<< "Street: " << street << endl
		<< "City: " << city << endl
		<< "State: " << state << endl
		<< "Zip Code: " << zipCode << endl;
	//address.displayAddress();
}
