#pragma once


// CAddAddressDlg dialog

class CAddAddressDlg : public CDialog
{
	DECLARE_DYNAMIC(CAddAddressDlg)

public:
	CAddAddressDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CAddAddressDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG_ADD };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
};
