// FindDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Assign4Prob3.h"
#include "FindDlg.h"
#include "afxdialogex.h"


// CFindDlg dialog

IMPLEMENT_DYNAMIC(CFindDlg, CDialog)

CFindDlg::CFindDlg(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_DIALOG1, pParent)
{

}

CFindDlg::~CFindDlg()
{
}

void CFindDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CFindDlg, CDialog)
END_MESSAGE_MAP()


// CFindDlg message handlers
