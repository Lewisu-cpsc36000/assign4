
// Assign4Prob3Doc.h : interface of the CAssign4Prob3Doc class
//


#pragma once

class CAssign4Prob3Doc : public CDocument
{
protected: // create from serialization only
	CAssign4Prob3Doc();
	DECLARE_DYNCREATE(CAssign4Prob3Doc)

// Attributes
public:

// Operations
public:

// Overrides
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
#ifdef SHARED_HANDLERS
	virtual void InitializeSearchContent();
	virtual void OnDrawThumbnail(CDC& dc, LPRECT lprcBounds);
#endif // SHARED_HANDLERS

// Implementation
public:
	virtual ~CAssign4Prob3Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()

#ifdef SHARED_HANDLERS
	// Helper function that sets search content for a Search Handler
	void SetSearchContent(const CString& value);
#endif // SHARED_HANDLERS

#ifdef SHARED_HANDLERS
private:
	CString m_strSearchContent;
	CString m_strThumbnailContent;
#endif // SHARED_HANDLERS
public:
	afx_msg void OnAddressAdd();
	afx_msg void OnUpdateAddressAdd(CCmdUI *pCmdUI);
	afx_msg void OnAddressFind();
	afx_msg void OnUpdateAddressFind(CCmdUI *pCmdUI);
};
