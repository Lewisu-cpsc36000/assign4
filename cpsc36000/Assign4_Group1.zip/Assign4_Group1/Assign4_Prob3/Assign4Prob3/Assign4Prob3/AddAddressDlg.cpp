// AddAddressDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Assign4Prob3.h"
#include "AddAddressDlg.h"
#include "afxdialogex.h"


// CAddAddressDlg dialog

IMPLEMENT_DYNAMIC(CAddAddressDlg, CDialog)

CAddAddressDlg::CAddAddressDlg(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_DIALOG2, pParent)
{

}

CAddAddressDlg::~CAddAddressDlg()
{
}

void CAddAddressDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CAddAddressDlg, CDialog)
END_MESSAGE_MAP()


// CAddAddressDlg message handlers
