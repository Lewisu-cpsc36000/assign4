
// Assign4Prob3View.cpp : implementation of the CAssign4Prob3View class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "Assign4Prob3.h"
#endif

#include "Assign4Prob3Doc.h"
#include "Assign4Prob3View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAssign4Prob3View

IMPLEMENT_DYNCREATE(CAssign4Prob3View, CEditView)

BEGIN_MESSAGE_MAP(CAssign4Prob3View, CEditView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CAssign4Prob3View::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
END_MESSAGE_MAP()

// CAssign4Prob3View construction/destruction

CAssign4Prob3View::CAssign4Prob3View()
{
	// TODO: add construction code here

}

CAssign4Prob3View::~CAssign4Prob3View()
{
}

BOOL CAssign4Prob3View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	BOOL bPreCreated = CEditView::PreCreateWindow(cs);
	cs.style &= ~(ES_AUTOHSCROLL|WS_HSCROLL);	// Enable word-wrapping

	return bPreCreated;
}


// CAssign4Prob3View printing


void CAssign4Prob3View::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CAssign4Prob3View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default CEditView preparation
	return CEditView::OnPreparePrinting(pInfo);
}

void CAssign4Prob3View::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView begin printing
	CEditView::OnBeginPrinting(pDC, pInfo);
}

void CAssign4Prob3View::OnEndPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView end printing
	CEditView::OnEndPrinting(pDC, pInfo);
}

void CAssign4Prob3View::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CAssign4Prob3View::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CAssign4Prob3View diagnostics

#ifdef _DEBUG
void CAssign4Prob3View::AssertValid() const
{
	CEditView::AssertValid();
}

void CAssign4Prob3View::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}

CAssign4Prob3Doc* CAssign4Prob3View::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CAssign4Prob3Doc)));
	return (CAssign4Prob3Doc*)m_pDocument;
}
#endif //_DEBUG


// CAssign4Prob3View message handlers
