#include "mainwindow.h"
#include "ui_mainwindow.h"
#define MAX_NUM_CONTACTS 100

class Contacts {
public:
    QString firstName[MAX_NUM_CONTACTS];
    QString lastName[MAX_NUM_CONTACTS];
    QString phoneNumber[MAX_NUM_CONTACTS];
};

int numContacts = 0;

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    Contacts Contact;

    ui -> setupUi(this);

    addEntryConnection = connect(ui -> addEntry, &QPushButton::clicked, this, &MainWindow::addEntry);
    delEntriesForNameConnection = connect(ui -> deleteEntry, &QPushButton::clicked, this, &MainWindow::delEntriesForName);
    getEntriesForNameConnection = connect(ui -> getEntry, &QPushButton::clicked, this, &MainWindow::getEntriesForName);
    listEntriesConnection = connect(ui -> listEntries, &QPushButton::clicked, this, &MainWindow::listEntries);
    delEntryForNumConnection = connect(ui -> deleteEntryNum, &QPushButton::clicked, this, &MainWindow::delEntryForNum);
    getEntryForNumConnection = connect(ui -> getEntryNum, &QPushButton::clicked, this, &MainWindow::getEntryForNum);
    quitConnection = connect(ui -> quit, &QPushButton::clicked, this, &MainWindow::quit);
}

void MainWindow::addEntry(Contacts &Contact, int &numContacts) {
    if (numContacts < MAX_NUM_CONTACTS) {
        // Entering contact info
        // cout
        ui -> plainTextEdit -> appendPlainText(QString("Enter contact's first name in the input window"));
        // cin
        Contact.firstName[numContacts] = ui -> plainTextEditInput -> toPlainText();
        // Clear window
        ui -> plainTextEditInput -> clear();
        ui -> plainTextEdit -> appendPlainText(QString("Enter contact's last name in input window"));
        Contact.lastName[numContacts] = ui -> plainTextEditInput -> toPlainText();
        ui -> plainTextEditInput -> clear();

        ui -> plainTextEdit -> appendPlainText(QString("Enter contact's phone number in input window"));
        Contact.phoneNumber[numContacts] = ui -> plainTextEditInput -> toPlainText();
        ui -> plainTextEditInput -> clear();

        numContacts++; // Incrementing number of contacts
    } else {
        ui -> plainTextEdit -> appendPlainText(QString("You have reached the maximum number of contacts"));
    }
}

void MainWindow::delEntriesForName(Contacts &Contact, int &numContacts) {
    if (numContacts == 0) {
        ui -> plainTextEdit -> appendPlainText(QString("There are no contacts"));
    } else {
        QString searchFirst, searchLast;
        QString firstName, lastName, phoneNumber;
        int contactPosition;
        bool contactFound = false;

        ui -> plainTextEdit -> appendPlainText(QString("Enter first name of the contact you wish to delete in the input window"));
        searchFirst = ui -> plainTextEditInput -> toPlainText();
        ui -> plainTextEditInput -> clear();
        ui -> plainTextEdit -> appendPlainText(QString("Enter last name of the contact you wish to delete in the input window"));
        searchLast = ui -> plainTextEditInput -> toPlainText();
        ui -> plainTextEditInput -> clear();

        for (int i = 0; i < numContacts; i++) { // Incrementing through each contact and....
            if (searchFirst == Contact.firstName[i] && searchLast == Contact.lastName[i]) { // ...checking to see if first and last names match the entered query
                firstName = Contact.firstName[i];
                lastName = Contact.lastName[i];
                phoneNumber = Contact.phoneNumber[i];
                contactPosition = i;
                contactFound = true;
            }
        }
        if (contactFound) {
            for (int i = contactPosition; i == numContacts; i++) {
                Contact.firstName[i] = Contact.firstName[i + 1];
                Contact.lastName[i] = Contact.lastName[i + 1];
                Contact.phoneNumber[i] = Contact.phoneNumber[i + 1];
            }
            Contact.firstName[contactPosition] = "";
            Contact.lastName[contactPosition] = "";
            Contact.phoneNumber[contactPosition] = "";
        } else {
            ui -> plainTextEdit -> appendPlainText(QString("No contact found"));
        }
    }
}

void MainWindow::getEntriesForName(Contacts &Contact, int &numContacts) {
    if (numContacts == 0) {
        ui -> plainTextEdit -> appendPlainText(QString("There are no contacts"));
    } else {
        QString searchFirst, searchLast;
        QString firstName, lastName, phoneNumber;
        bool contactFound = false;

        ui -> plainTextEdit -> appendPlainText(QString("Enter first name of the contact you wish to delete in the input window"));
        searchFirst = ui -> plainTextEditInput -> toPlainText();
        ui -> plainTextEditInput -> clear();
        ui -> plainTextEdit -> appendPlainText(QString("Enter last name of the contact you wish to delete in the input window"));
        searchLast = ui -> plainTextEditInput -> toPlainText();
        ui -> plainTextEditInput -> clear();

        for (int i = 0; i < numContacts; i++) { // Incrementing through each contact and....
            if (searchFirst == Contact.firstName[i] && searchLast == Contact.lastName[i]) { // ...checking to see if first and last names match the entered query
                firstName = Contact.firstName[i];
                lastName = Contact.lastName[i];
                phoneNumber = Contact.phoneNumber[i];
                contactFound = true;
            }
        }
        if (contactFound) {
            ui -> plainTextEdit -> appendPlainText(QString("Contact Found!"));
            ui -> plainTextEdit -> appendPlainText(QString("Name: " + firstName + " " + lastName));
            ui -> plainTextEdit -> appendPlainText(QString("Phone Number: " + phoneNumber));
        } else {
            ui -> plainTextEdit -> appendPlainText(QString("No contact found"));
        }
    }
}

void MainWindow::listEntries(Contacts &Contact, int &numContacts) {
    if (numContacts == 0) {
        ui -> plainTextEdit -> appendPlainText(QString("There are no contacts"));
    } else {
        for (int i = 0; i < numContacts; i++) {
            if (Contact.firstName[i] != "" && Contact.lastName[i] != "" && Contact.phoneNumber[i] != "") {
                ui -> plainTextEdit -> appendPlainText(QString("Name: " + Contact.firstName[i] + " " + Contact.lastName[i]));
                ui -> plainTextEdit -> appendPlainText(QString("Phone Number: " + Contact.phoneNumber[i]));
            }
        }
    }
}

void MainWindow::delEntryForNum(Contacts &Contact, int &numContacts) {
    if (numContacts == 0) {
        ui -> plainTextEdit -> appendPlainText(QString("There are no contacts"));
    } else {
        QString searchNum;
        QString firstName, lastName, phoneNumber;
        int contactPosition;
        bool contactFound = false;

        ui -> plainTextEdit -> appendPlainText(QString("Enter the number of the contact you wish to delete in the input window"));
        searchNum = ui -> plainTextEditInput -> toPlainText();
        ui -> plainTextEditInput -> clear();

        for (int i = 0; i < numContacts; i++) { // Incrementing through each contact and....
            if (searchNum == Contact.phoneNumber[i]) { // ...checking to see if first and last names match the entered query
                firstName = Contact.firstName[i];
                lastName = Contact.lastName[i];
                phoneNumber = Contact.phoneNumber[i];
                contactPosition = i;
                contactFound = true;
            }
        }
        if (contactFound) {
            for (int i = contactPosition; i == numContacts; i++) {
                Contact.firstName[i] = Contact.firstName[i + 1];
                Contact.lastName[i] = Contact.lastName[i + 1];
                Contact.phoneNumber[i] = Contact.phoneNumber[i + 1];
            }
            Contact.firstName[contactPosition] = "";
            Contact.lastName[contactPosition] = "";
            Contact.phoneNumber[contactPosition] = "";
        } else {
            ui -> plainTextEdit -> appendPlainText(QString("No contact found"));
        }
    }
}

void MainWindow::getEntryForNum(Contacts &Contact, int &numContacts) {
    if (numContacts == 0) {
        ui -> plainTextEdit -> appendPlainText(QString("There are no contacts"));
    } else {
        QString searchNum;
        QString firstName, lastName, phoneNumber;
        bool contactFound = false;

        ui -> plainTextEdit -> appendPlainText(QString("Enter the number of the contact you wish to show in the input window"));
        searchNum = ui -> plainTextEditInput -> toPlainText();
        ui -> plainTextEditInput -> clear();

        for (int i = 0; i < numContacts; i++) { // Incrementing through each contact and....
            if (searchNum == Contact.phoneNumber[i]) { // ...checking to see if first and last names match the entered query
                firstName = Contact.firstName[i];
                lastName = Contact.lastName[i];
                phoneNumber = Contact.phoneNumber[i];
                contactFound = true;
            }
        }
        if (contactFound) {
            ui -> plainTextEdit -> appendPlainText(QString("Contact Found!"));
            ui -> plainTextEdit -> appendPlainText(QString("Name: " + firstName + " " + lastName));
            ui -> plainTextEdit -> appendPlainText(QString("Phone Number: " + phoneNumber));
        } else {
            ui -> plainTextEdit -> appendPlainText(QString("No contact found"));
        }
    }
}

/*void MainWindow::quit() {
    this -> close();
}*/

MainWindow::~MainWindow()
{
    delete ui;
}
