#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPlainTextEdit>

namespace Ui {
class MainWindow;
}

class Contacts;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void addEntry(Contacts &Contact, int &numContacts);
    void delEntriesForName(Contacts &Contact, int &numContacts);
    void getEntriesForName(Contacts &Contact, int &numContacts);
    void listEntries(Contacts &Contact, int &numContacts);
    void delEntryForNum(Contacts &Contact, int &numContacts);
    void getEntryForNum(Contacts &Contact, int &numContacts);
    void quit();

private:
    Ui::MainWindow *ui;

    QMetaObject::Connection addEntryConnection;
    QMetaObject::Connection delEntriesForNameConnection;
    QMetaObject::Connection getEntriesForNameConnection;
    QMetaObject::Connection listEntriesConnection;
    QMetaObject::Connection delEntryForNumConnection;
    QMetaObject::Connection getEntryForNumConnection;
    QMetaObject::Connection quitConnection;

};

#endif // MAINWINDOW_H
