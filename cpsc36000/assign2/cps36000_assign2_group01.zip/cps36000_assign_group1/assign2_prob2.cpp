#include <cstdlib>
#include <iostream>
#include <string>
#include <stdlib.h> 
#include <vector>

//Coded by Thomas Poorman
/******************************************************************************
Title: assign_prob6.cpp
Author: Thomas Poorman
Created on: October 18th, 2016
Description: Takes inputs from user, determining if the highest test score is 
above 100 or below / equal to 100, before iterating through the vector used to 
normalize the test scores.
******************************************************************************/

using namespace std;
int main(){  
    //For loop to let program continue to run until execution.
    for(;;){
        //Declaration of variables we need to reinstance after every loop.
        vector<int> scoreVector;
        int myint;
        int scoreMax;
        int score;

        cout<< "\nAdd new test scores. Add 0 to end input. \n"; 
        //Prompt for user to input test scores.
        do {
          cin >> myint;
          scoreVector.push_back (myint); 
          } 
          while (myint);
      
        //Loops through vector to find highest number, which the program will use to normalize the numbers.
        for(int i = 0; i < scoreVector.size()-1; i++){
              
              if(scoreVector[i] > scoreMax){
                 scoreMax = scoreVector[i];
                }
        } 
        //If highest number is a number below or equal to 100, program will normalize upwards, or keep numbers the same. 
        if(scoreMax <= 100){
            cout<<"Normalized Test scores: ";

            int normalizeInt = 100 - scoreMax;
        
            for (int i = 0; i < scoreVector.size()-1; i++) {
            score= scoreVector[i] + normalizeInt;
            cout<<score;  
            cout<<" "; 
        }
     }
     
    //If there is a score above 100, the program will instead normalize it downwards.
        if(scoreMax > 100){
            cout<<"Normalized Test scores: ";
            int normalizeInt = scoreMax - 100;
        
            for(int i = 0; i < scoreVector.size()-1; i++){
                score = scoreVector[i] - normalizeInt;
             
                cout<<score;
                cout<<" ";
            }
        }
        
    }
    return 0;
}