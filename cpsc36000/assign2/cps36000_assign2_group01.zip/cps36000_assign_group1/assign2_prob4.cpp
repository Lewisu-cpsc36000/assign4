/**
	Title: assign1_prob4.cpp
	Author: Adrian Siwy
	Creation Date: 10/18/16
	Description: The program allows the user to enter a persons address data and then display it
	Purpose: The purpose is to show the PersonData object and correctly access its data.
	Usage: Run the application and enter the required data.
	Modifications: I had to remove Address object from PersonData's instance vars since the compiler would not compile.
*/

#include <iostream>
#include <string>
#include <vector>

using namespace std;

//The class that stores an individuals data
class PersonData {

private:
	string firstName;
	string lastName;
	//These were in the Address object before but for some reason the compiler was freaking out
	string street;
	string city;
	string state;
	string zipCode;

public:
	//constructor
	PersonData(string firstName, string lastName, string street, string city, string state, string zipCode) {
		this->firstName = firstName;
		this->lastName = lastName;
		this->street = street;
		this->city = city;
		this->state = state;
		this->zipCode = zipCode;
		//address.setAddress(street, city, state, zipCode);
	}
	//safely return only the first name of the person
	string getFirstName() {
		return firstName;
	}
	//display the person's data
	void displayData() {
		cout << "Name:" << endl
			<< firstName << " "
			<< lastName << endl
			<< "Address:" << endl
			<< "Street: " << street << endl
			<< "City: " << city << endl
			<< "State: " << state << endl
			<< "Zip Code: " << zipCode << endl;
		//address.displayAddress();
	}

};

/* Tried making this class work, for some reason the compiler was giving errors
class Address {

private:
	string street;
	string city;
	string state;
	string zipCode;

public:
	void setAddress(string street, string city, string state, string zipCode) {
		this->street = street;
		this->city = city;
		this->state = state;
		this->zipCode = zipCode;
	}
	void displayAddress() {
		cout << "Address:" << endl
			<< "Street: " << street << endl
			<< "City: " << city << endl
			<< "State: " << state << endl
			<< "Zip Code: " << zipCode << endl;
	}
};
*/

int main() {

	//create the vector of people
	vector<PersonData> data;

	//data to be entered
	string firstName;
	string lastName;
	string street;
	string city;
	string state;
	string zipCode;

	//ask the user to input data
	char exit;
	do {
		cout << "Enter name: ";
		cin >> firstName;
		cout << "Enter last name: ";
		cin >> lastName;
		cout << "Enter street: ";
		cin >> street;
		cout << "Enter city: ";
		cin >> city;
		cout << "Enter state: ";
		cin >> state;
		cout << "Enter zipcode: ";
		cin >> zipCode;
		PersonData newEntry = PersonData(firstName, lastName, street, city, state, zipCode);
		data.push_back(newEntry);
		cout << "Enter another user? (y/n) ";
		cin >> exit;
	} while (exit == 'y' || exit == 'Y');

	string enteredName;

	//the user inputs a name
	cout << "Enter a user's name to display their data";
	cin >> enteredName;

	//search the vector for the person with the first name and display their data
	for (int i = 0; i < data.size(); ++i) {
		if (data[i].getFirstName() == enteredName) {
			data[i].displayData();
		}
	}

	system("pause");

	return 0;
}