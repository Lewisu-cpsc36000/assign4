/******************************************************************************
Title: assign2_prob1.cpp
Author: Lenny Flores
Created on: October 11, 2016
Description: This program stores contacts in an array and the user is able to
	manage the contacts how they would like to
Purpose: Add, Remove and List contacts from an array
Usage: Type in the letter (case sensitive) of the menu that you want then
	follow the on screen instructions
Modifications: October 18, 2016
	Finished code and made some adjustments
******************************************************************************/

#include "stdafx.h"
#include <iostream>
#include <string>
using namespace std;

#define MAX_NUM_CONTACTS 100

class Contacts {
public:
	string firstName[MAX_NUM_CONTACTS];
	string lastName[MAX_NUM_CONTACTS];
	string phoneNumber[MAX_NUM_CONTACTS];
};

// List of functions to see all of the different ones and call them
void addEntry(Contacts &Contact, int &numContacts);
void delEntriesForName(Contacts &Contact, int &numContacts);
void getEntriesForName(Contacts &Contact, int &numContacts);
void listEntries(Contacts &Contact, int &numContacts);
void delEntryForNum(Contacts &Contact, int &numContacts);
void getEntryForNum(Contacts &Contact, int &numContacts);

int main() {
	Contacts Contact;
	char option;
	bool keepGoing = true;
	int numContacts = 0;
	
	do {
		cout << "MENU" << endl;
		cout << "A: Add an entry" << endl;
		cout << "D: Delete an entry for a name" << endl;
		cout << "G: Get entries for a name" << endl;
		cout << "L: List entries" << endl;
		cout << "d: Delete an entry for a number" << endl;
		cout << "g: Get the entry for a number" << endl;
		cout << "Q: Quit" << endl;
		cout << "Selection: ";
		cin >> option;
		// Switch statement menu
		switch (option) {
		case 'A':
			if (numContacts < MAX_NUM_CONTACTS) {
				addEntry(Contact, numContacts);
			}
			else if (numContacts >= MAX_NUM_CONTACTS) {
				cout << "You have reached the maximum number of contacts";
			}
			break;

		case 'D':
			if (numContacts == 0) {
				cout << "There are no contacts" << endl;
			}
			else {
				delEntriesForName(Contact, numContacts);
			}
			break;

		case 'G':
			if (numContacts == 0) {
				cout << "There are no contacts" << endl;
			}
			else {
				getEntriesForName(Contact, numContacts);
			}
			break;
		
		case 'L':
			if (numContacts == 0) {
				cout << "There are no contacts" << endl;
			}
			else {
				listEntries(Contact, numContacts);
			}
			break;

		case 'd':
			if (numContacts == 0) {
				cout << "There are no contacts" << endl;
			}
			else {
				delEntryForNum(Contact, numContacts);
			}
			break;

		case 'g':
			if (numContacts == 0) {
				cout << "There are no contacts" << endl;
			}
			else {
				getEntryForNum(Contact, numContacts);
			}
			break;

		case 'Q':
			keepGoing = false;
			break;

		default:
			cout << "Please pick a valid option." << endl;
			cout << "Selection is case sensitive." << endl;
			cout << endl;
			break;
		}
		cout << endl;
	} while (keepGoing == true);

	return 0;
}

void addEntry(Contacts &Contact, int &numContacts) {
	// Entering contact info
	cout << "Enter contact's first and last name: ";
	cin >> Contact.firstName[numContacts] >> Contact.lastName[numContacts];

	cout << "Enter contact's phone number: ";
	cin >> Contact.phoneNumber[numContacts];

	numContacts++; // Incrementing number of contacts
}

void delEntriesForName(Contacts &Contact, int &numContacts) {
	string searchFirst, searchLast;
	string firstName, lastName, phoneNumber;
	int contactPosition;
	bool contactFound = false;

	cout << "Enter first and last name of the contact you wish to delete: ";
	cin >> searchFirst >> searchLast; // Getting search parameters for first and last name

	for (int i = 0; i < numContacts; i++) { // Incrementing through each contact and....
		if (searchFirst == Contact.firstName[i] && searchLast == Contact.lastName[i]) { // ...checking to see if first and last names match the entered query
			firstName = Contact.firstName[i];
			lastName = Contact.lastName[i];
			phoneNumber = Contact.phoneNumber[i];
			contactPosition = i;
			contactFound = true;
		}
	}
	if (contactFound) {
		for (int i = contactPosition; i == numContacts; i++) {
			Contact.firstName[i] = Contact.firstName[i + 1];
			Contact.lastName[i] = Contact.lastName[i + 1];
			Contact.phoneNumber[i] = Contact.phoneNumber[i + 1];
		}
		Contact.firstName[contactPosition] = "";
		Contact.lastName[contactPosition] = "";
		Contact.phoneNumber[contactPosition] = "";
	} else {
		cout << "No contact found" << endl;
	}
}

void getEntriesForName(Contacts &Contact, int &numContacts) {
	string searchFirst, searchLast;
	string firstName, lastName, phoneNumber;
	bool contactFound = false;

	cout << "Enter first and last name of the contact you wish to show: ";
	cin >> searchFirst >> searchLast; // Getting search parameters for first and last name

	for (int i = 0; i < numContacts; i++) { // Incrementing through each contact and....
		if (searchFirst == Contact.firstName[i] && searchLast == Contact.lastName[i]) { // ...checking to see if first and last names match the entered query
			firstName = Contact.firstName[i];
			lastName = Contact.lastName[i];
			phoneNumber = Contact.phoneNumber[i];
			contactFound = true;
		}
	}
	if (contactFound) {
		cout << "Contact Found!" << endl;
		cout << "Name: " << firstName << " " << lastName << endl;
		cout << "Phone Number: " << phoneNumber << endl;
	} else {
		cout << "No contact found" << endl;
	}
}

void listEntries(Contacts &Contact, int &numContacts) {
	for (int i = 0; i < numContacts; i++) {
		if (Contact.firstName[i] != "" && Contact.lastName[i] != "" && Contact.phoneNumber[i] != "") {
			cout << "Name: " << Contact.firstName[i] << " " << Contact.lastName[i] << endl;
			cout << "Phone Number: " << Contact.phoneNumber[i] << endl;
		}
	}
}

void delEntryForNum(Contacts &Contact, int &numContacts) {
	string searchNum;
	string firstName, lastName, phoneNumber;
	int contactPosition;
	bool contactFound = false;

	cout << "Enter the number of the contact you wish to delete: ";
	cin >> searchNum; // Getting search parameters for phone number

	for (int i = 0; i < numContacts; i++) { // Incrementing through each contact and....
		if (searchNum == Contact.phoneNumber[i]) { // ...checking to see if first and last names match the entered query
			firstName = Contact.firstName[i];
			lastName = Contact.lastName[i];
			phoneNumber = Contact.phoneNumber[i];
			contactPosition = i;
			contactFound = true;
		}
	}
	if (contactFound) {
		for (int i = contactPosition; i == numContacts; i++) {
			Contact.firstName[i] = Contact.firstName[i + 1];
			Contact.lastName[i] = Contact.lastName[i + 1];
			Contact.phoneNumber[i] = Contact.phoneNumber[i + 1];
		}
		Contact.firstName[contactPosition] = "";
		Contact.lastName[contactPosition] = "";
		Contact.phoneNumber[contactPosition] = "";
	} else {
		cout << "No contact found" << endl;
	}
}

void getEntryForNum(Contacts &Contact, int &numContacts) {
	string searchNum;
	string firstName, lastName, phoneNumber;
	bool contactFound = false;

	cout << "Enter the number of the contact you wish to show: ";
	cin >> searchNum; // Getting search parameters for phone number

	for (int i = 0; i < numContacts; i++) { // Incrementing through each contact and....
		if (searchNum == Contact.phoneNumber[i]) { // ...checking to see if first and last names match the entered query
			firstName = Contact.firstName[i];
			lastName = Contact.lastName[i];
			phoneNumber = Contact.phoneNumber[i];
			contactFound = true;
		}
	}
	if (contactFound) {
		cout << "Contact Found!" << endl;
		cout << "Name: " << firstName << " " << lastName << endl;
		cout << "Phone Number: " << phoneNumber << endl;
	} else {
		cout << "No contact found" << endl;
	}
}