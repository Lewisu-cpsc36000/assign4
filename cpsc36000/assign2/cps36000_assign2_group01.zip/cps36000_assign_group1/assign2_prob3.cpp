/******************************************************************************
Title: Assign2_Prob3.cpp
Author: David Gagnon
Created on: 10/16/2016
Description: Creates a Clock, in which the user inputs the hour,
minute, and second, as well as whether it be A.M. or P.M.
Purpose: To demonstrate the use of time in a program, as well as using
a class.
Usage: Assign2_Prob3
Enter in a number for the hour, from 1 to 12, and then press the Enter button
then enter in a number for the minutes, from 0 to 60, and then press the Enter button
then enter in a number for the seconds, from 0 to 60, and then press the Enter button
finealy enter a "p" for P.M. or "a" for A.M. and then press the Enter button
Then just sit and watch as you now have your very own clock.
Build with: Visual Studio
Build with : gcc -o drawing_demo draw_stars.c (or Visual Studio)
Modifications: 10/19/2016: made it so that it clears the string before entering a new time.
******************************************************************************/
//The following includes specific header files
#include "stdafx.h"
#include <iostream>
#include <Windows.h>
using namespace std; //creates the namespace std

					 //The following is the Clock class
class Clock {
public:
	int a = 1;
	int hour = 900;
	int minute = 900;
	int second = 900;
	char DN = 'q';
	char AMPM;
};

//the following is the main class
int main()
{
	Clock clocks;	//initializes the clock

					//The following asks the user for the hour, minute, second, and whether or not it is A.M. or P.M. as well as make sure that they are within acceptable values
	while ((clocks.hour < 1) || (clocks.hour > 12)) {
		cout << "please enter what hour it is: ";
		cin >> clocks.hour;
	}
	while ((clocks.minute < 0) || (clocks.minute >= 60)) {
		cout << "please enter what minute it is: ";
		cin >> clocks.minute;
	}
	while ((clocks.second < 0) || (clocks.second >= 60)) {
		cout << "please enter what second it is: ";
		cin >> clocks.second;
	}
	while ((clocks.DN != 'a') && (clocks.DN != 'p')) {
		cout << "enter \"a\" for A.M. or \"p\" for P.M.: ";
		cin >> clocks.DN;
	}
	if (clocks.DN == 'a') {
		clocks.AMPM = 'A';
	}
	else {
		clocks.AMPM = 'P';
	}

	//the following is the while loop where the clock is displayed, and adds 1 to the second.
	while (1 == clocks.a) {

		system("cls");//clears the screen

					  //the following displays the clock appropriately
		if ((clocks.second >= 0) && (clocks.second < 10)) {
			if ((clocks.minute >= 0) && (clocks.minute < 10)) {
				cout << clocks.hour << ":" << "0" << clocks.minute << ":" << "0" << clocks.second << " " << clocks.AMPM << ".M." << endl;
			}
			else {
				cout << clocks.hour << ":" << clocks.minute << ":" << "0" << clocks.second << " " << clocks.AMPM << ".M." << endl;
			}
		}
		else {
			if ((clocks.minute >= 0) && (clocks.minute < 10)) {
				cout << clocks.hour << ":" << "0" << clocks.minute << ":" << clocks.second << " " << clocks.AMPM << ".M." << endl;
			}
			else {
				cout << clocks.hour << ":" << clocks.minute << ":" << clocks.second << " " << clocks.AMPM << ".M." << endl;
			}
		}

		//the following adds one to the second, and makes sure that the seconds, minutes, and hours are all changed when needed.
		clocks.second++;
		if (60 == clocks.second) {
			clocks.second = 0;
			clocks.minute++;
			if (60 == clocks.minute) {
				clocks.minute = 0;
				clocks.hour++;
				if (13 == clocks.hour) {
					if (clocks.AMPM == 'A') {
						clocks.AMPM = 'P';
					}
					else {
						clocks.AMPM = 'A';
					}
					clocks.hour = 1;
				}
			}
		}
		Sleep(1000);//pauses the program for 1000 ms, or 1 second.
	}
}