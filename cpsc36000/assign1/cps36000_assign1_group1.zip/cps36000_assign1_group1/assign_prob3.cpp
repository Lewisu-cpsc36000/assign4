/******************************************************************************
Title: assign_prob3.cpp
Author: David Gagnon
Created on: 9/30/2016
Description:This is a program that allows an unlimited number of values to be
	entered and stored in an array.  Then the program will output the values, five
	to a line, followed by the average of the values entered. The array will be five
	elements to start and grow when needed.
Purpose:To find the average of numbers and then print the list of numbers as
	well as the average to the screen
Usage: assign_prob3
	Enter a number followed by an enter.
	Then enter a "y" if you want to enter another number, or any other element
	in order to not enter another number, followed by an enter.
Modifications:
10/1/2016:
	made it so that an infinite number of variables can be added to the array.
******************************************************************************/
#include "stdafx.h"
#include <iostream>
#include <string>

using namespace std;


int main()
{
	int numOfInputs = 5;		// This is the number of inputs the array can take.
	int* inputs;		//this, as well as the following line create the array.
	inputs = new(nothrow) int[numOfInputs];
	double totalInputs = 0;			//this takes in the total amount of inputs that are entered.
	double average = 0;			//this is  the average variable
	double total = 0;				//This is all the numbers added together.
	string doAgain;				//This string will take an input to say whether or not they want to add another number
	int newLine = 1;	
	for (int i = 0; i >= 0; i++) {	
		if (numOfInputs <= (i+2)) {		//This if statment makes it so that if there isnt room in the Array, it will add more space.
			numOfInputs = numOfInputs + 5;
			int * newInputs;
			newInputs = new(nothrow) int[numOfInputs];
			for (int j = 0; j <= i; j++) {
				newInputs[j] = inputs[j];
			}
			//int * inputs; (not seen to be needed so removed but saved incase needed)
			inputs = new(nothrow) int[numOfInputs];
			for (int j = 0; j <= i; j++) {
				inputs[j] = newInputs[j];
			}
			delete[] newInputs;
		}
			cout << "Input number: ";	//asks the user to input a number
			cin >> inputs[i];
			total = total + inputs[i];
			cout << "Add another number? (y/n) ";	//asks the user if they would like to input another number.
			totalInputs = totalInputs + 1;
			cin >> doAgain;
			if ((doAgain == "y") || (doAgain == "yes") || (doAgain == "Y") || (doAgain == "Yes") || (doAgain == "YES")) {

			}
			else {
				i = -50;
			}
	}
	average = (total/totalInputs);		//takes the average of all the numbers 
	cout << "You inputed " << totalInputs << " numbers, \nThey are as follows:" << endl;		//displays all the numbers inputted
	for (int i = 0; i < totalInputs; i++) {
		cout << inputs[i] << " ";
		if (5 <= newLine) {		//if there are five variables displayed on a line, this will make it go to a new line
			cout << "\n";
			newLine = 1;
		}
		else {
			newLine++;
		}			
	}
	cout << "\n";				//This will happen after all the varaibles have been displayed to go to a new line.
	cout << "The average number inputed was: " << average << endl;		//This will display the average number.
	system("pause");
    return 0;
}