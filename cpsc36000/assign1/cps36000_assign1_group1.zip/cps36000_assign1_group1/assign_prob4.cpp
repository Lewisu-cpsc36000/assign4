/******************************************************************************
Title: assign_prob4.cpp
Author: Lenny Flores
Created on: September 22, 2016
Description: Takes in a string that the user inputs and it separates each word
	by using the spaces as markers to where the program should separate the
	sentence by
Purpose: This program parses a string that is inputed by the user
Usage: Type a string that will be parsed by the program using the spaces as
	delimiters
Modifications: October 1, 2016
	Made the code less bulky and more streamline (condensed)
******************************************************************************/

#include "stdafx.h"
#include <string>
#include <iostream>
using namespace std;

int main() {
	string str;
	string delimiter = " ";
	size_t current;
	size_t next = -1;

	cout << "Type in a string: ";
	getline(cin, str);

	do {
		current = next + 1;
		next = str.find_first_of(delimiter, current);
		cout << str.substr(current, next - current) << endl;
	} while (next != string::npos);

	system("pause");
	return 0;
}