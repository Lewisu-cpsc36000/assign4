/****************************************************************************** 
Title: assign_prob1_00.cpp
Author: Lenny Flores
Created on: September 22, 2016
Description: Uses a while loop to be able to add multiple numbers together
Purpose: This program adds numbers together using a while loop until the user
	inputs a zero
Usage: Type in numbers that you want to add and once you are finished type in a
	zero to be able to exit the while loop
Modifications: October 1, 2016
	Made the code less bulky and more streamline (condensed)
	Made the code handle multiple inputs better
******************************************************************************/

#include "stdafx.h"
#include <iostream>
#include <sstream>
#include <string>
using namespace std;

int main() {
    
	float input = 1;
	float addNum;
	string strInput;

	cout << "Type a number to add: ";
	getline(cin, strInput);
	stringstream(strInput) >> addNum;

	while (input != 0) {
		cout << "Type a number to add: ";
		getline(cin, strInput);
		stringstream(strInput) >> input;
		addNum = addNum + input;
		cout << "Result: " << addNum << "\n";
	}
	return 0;
}