/**
	Title: assign_prob5.cpp
	Author: Adrian Siwy
	Creation Date: 9/27/16
	Description: Uses a function pointer to call the method ascVal. 
		ascVal takes in two parameters (index and string) and returns the ASCII value of a char
	Purpose: Demonstrates the use of a function pointer to call a method.
	Usage: Provide an index and a string of at most index->chars
	Modifications: 10/1/16, actually made the thing work. 
		The function pointer was not properly implemented.
*/

#include <iostream>
#include <cstring>
#include <string>

using namespace std;

// Return the ASCII value of the char at index "ip" in string "p"
int ascVal(size_t ip, const char* p)
{
	// If p is not null and the index is in string
	if (!p || ip > strlen(p))
		return -1;
	else
		return p[ip];
}

int main() {

	// Test Data
	char* testString = "hello";
	int testCharIndex = 0;

	// Use of Function Pointer "val"
	int (*val)(size_t, const char*) = ascVal;
	cout << (*val)(testCharIndex, testString) << endl;

	system("pause");

	return 0;
}