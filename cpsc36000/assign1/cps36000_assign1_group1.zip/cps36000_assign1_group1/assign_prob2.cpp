/**
Title: assign_prob2.cpp
Author: Adrian Siwy
Creation Date: 9/27/16
Description: Uses a loop to count number of vowels entered.
Purpose: Demonstrates the use a loop to take user input.
	Use of a switch statement to check for vowels.
Usage: Enter in lowercase or capital characters and enter q to terminate the program.
Modifications: None.
*/

#include <iostream>

using namespace std;

int main() {

	//Init vars
	char input = 0;
	int vowelCount = 0;
	bool continueRunning = true;

	cout << "Input characters, type \"q\" or \"Q\" to exit." << endl;

	while (continueRunning) {

		//Make sure a char (or int) is given
		while (!(cin >> input)) {
			cout << "Input must be a char" << endl;
			cin.clear();
		}

		//Determine if a vowel was given
		switch (input) {
		case 'a':
		case 'A':
		case 'e':
		case 'E':
		case 'i':
		case 'I':
		case 'o':
		case 'O':
		case 'u':
		case 'U':
			vowelCount++;
			break;
		case 'q':
		case 'Q':
			//If q is entered, end the program
			continueRunning = false;
		}
	}

	cout << "The number of vowels you entered is: " << vowelCount << endl;

	system("pause");

	return 0;
}