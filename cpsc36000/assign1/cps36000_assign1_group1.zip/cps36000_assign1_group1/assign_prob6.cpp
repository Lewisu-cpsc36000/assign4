
#include <cstdlib>
#include <iostream>
#include <string>
#include <stdlib.h> 
//Coded by Thomas Poorman

using namespace std;

double accountBalance;
double numOfWithdrawls;
double numOfDeposits;
string month;
int zero;

//sets up data from user input
int reaData(){
    string input;
    cout << "Input current month.	\n";
    getline(cin, input);
    
    month = input;
    cout << "Input current account balance.	\n";
    getline(cin, input);

    accountBalance = atoi( input.c_str() );

    cout << "Input number of deposits.	\n";
    getline(cin, input);
    numOfWithdrawls = atoi( input.c_str() );

    cout << "Input number of withdrawls.	\n";
    getline(cin, input);
    numOfDeposits = atoi( input.c_str() );


    return 0;
    //Sets account data from user entries
       }



//adds deposit to overall balance and adds in 
void addDeposits(){
     string input;
     cout << "\nInsert deposit.	\n";
     getline(cin, input);
     accountBalance = accountBalance + atoi( input.c_str() );;
     numOfDeposits ++;
     //Adds deposits
       }
     
void subtractWithdrawls(){
     string input;
     cout << "Enter amount you wish to subtract.	\n";     
     getline(cin, input);
     accountBalance = accountBalance - atoi( input.c_str() );
     numOfWithdrawls ++;
     //Subtracts Withdrawls     
       } 
     

double calculateInterest(double input){
       cout << "\nCalculate interest.\n";
       double interest = input / 10;      
       double interest1 = interest + input;

       return interest1;
//Calculates Interest     
       }
     
void generateReport(double one, double two, double three, string month){
     double interest = calculateInterest(one);
     cout << " \nCurrent Month: ";
     cout << month;
     cout << "	\nCurrent Balance: "; 
     cout << one;
     cout << "	\nNumber of Deposits: ";
     cout << two;
     cout << "	\nNumber of Withdrawls: ";
     cout << three;
     cout << "	\nInterest Rate: ";
     cout << interest;
//Generates Report     
       }




int main(int argc, char *argv[])
{
    for(;;){
    cout<< "\nWelcome to the banking system.\n";
    cout<< "\nTo setup data, type 'Setup'\n";
    cout<< "To add a deposit, type 'Deposit'\n";
    cout<< "To withdraw, type 'Withdraw'\n";
    cout<< "For a report, type 'Report'\n";
    
    string answer;
    getline(cin, answer);
    //checks commands based on proper or lowercase capitalization
    //gives error message if misspelled
    //loops inifnitely to keep getting information
    if(answer == "Setup" || answer == "setup"){
              reaData();
              }
    else if(answer == "Deposit" || answer == "deposit"){
              addDeposits();
              }
    else if(answer == "Withdraw" || answer == "withdraw"){
              subtractWithdrawls();
              }
    else if(answer == "Report" || answer == "report"){
              generateReport(accountBalance, numOfDeposits, numOfWithdrawls, month);
              }
    else{
            cout<< "Command not found.\n";
           }
}
    
    zero = reaData();
    addDeposits();
    subtractWithdrawls();
    
    
    system("PAUSE");
    return EXIT_SUCCESS;
}




