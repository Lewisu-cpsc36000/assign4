/******************************************************************************
Title: assign_prob1_02.cpp
Author: Lenny Flores
Created on: September 22, 2016
Description: Uses a for loop to be able to add multiple numbers together
Purpose: This program adds numbers together using a for loop until the user
	inputs a zero
Usage: Type in numbers that you want to add and once you are finished type in a
	zero to be able to exit the for loop
Modifications: October 1, 2016
	Made the code less bulky and more streamline (condensed)
	Made the code handle multiple inputs better
******************************************************************************/

#include "stdafx.h"
#include <iostream>
#include <sstream>
#include <string>
using namespace std;

int main() {
	int input = 1;
	int addNum;
	string strInput;

	cout << "Type a number to add: ";
	getline(cin, strInput);
	stringstream(strInput) >> addNum;

	for (int i = 1; i > 0; i++) {
		cout << "Type a number to add: ";
		getline(cin, strInput);
		stringstream(strInput) >> input;
		addNum = addNum + input;
		cout << "Result: " << addNum << "\n";
		if (input == 0) {
			break;
		}
	}
	return 0;
}

